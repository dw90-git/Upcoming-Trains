// Train Departures App
class TrainDepartureApp {
    constructor() {
        // API Configuration - REPLACE THESE WITH YOUR ACTUAL CREDENTIALS
        this.apiConfig = {
            baseUrl: 'https://api.rtt.io/api/v1/json/search/WFJ/to/EUS',
            // TODO: Replace with your actual API credentials from https://api.rtt.io
            username: 'YOUR_RTT_USERNAME', // Replace with your RTT username
            password: 'YOUR_RTT_PASSWORD'  // Replace with your RTT password
        };

        this.refreshInterval = 60000; // 60 seconds
        this.maxTrains = 2;
        this.countdownInterval = null;
        this.autoRefreshInterval = null;
        this.autoRefreshCountdown = 60;

        this.elements = {
            loadingState: document.getElementById('loadingState'),
            errorState: document.getElementById('errorState'),
            noTrainsState: document.getElementById('noTrainsState'),
            trainsContainer: document.getElementById('trainsContainer'),
            refreshBtn: document.getElementById('refreshBtn'),
            retryBtn: document.getElementById('retryBtn'),
            errorMessage: document.getElementById('errorMessage'),
            countdown: document.getElementById('countdown')
        };

        this.init();
    }

    init() {
        this.bindEvents();
        this.loadTrains();
        this.startAutoRefresh();
    }

    bindEvents() {
        this.elements.refreshBtn.addEventListener('click', () => {
            this.loadTrains();
            this.resetAutoRefresh();
        });

        this.elements.retryBtn.addEventListener('click', () => {
            this.loadTrains();
            this.resetAutoRefresh();
        });
    }

    async loadTrains() {
        this.showLoadingState();
        this.elements.refreshBtn.classList.add('refreshing');

        try {
            // Check if credentials are still placeholder values
            if (this.apiConfig.username === 'YOUR_RTT_USERNAME' || 
                this.apiConfig.password === 'YOUR_RTT_PASSWORD') {
                throw new Error('API credentials not configured. Please replace the placeholder credentials in the code with your actual credentials from api.rtt.io');
            }

            const response = await this.fetchTrainData();
            const trains = this.parseTrainData(response);
            
            if (trains.length === 0) {
                this.showNoTrainsState();
            } else {
                this.displayTrains(trains);
            }
        } catch (error) {
            console.error('Error loading trains:', error);
            this.showErrorState(error.message);
        } finally {
            this.elements.refreshBtn.classList.remove('refreshing');
        }
    }

    async fetchTrainData() {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

        try {
            const response = await fetch(this.apiConfig.baseUrl, {
                method: 'GET',
                headers: {
                    'Authorization': 'Basic ' + btoa(`${this.apiConfig.username}:${this.apiConfig.password}`),
                    'Accept': 'application/json'
                },
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                if (response.status === 401) {
                    throw new Error('Authentication failed. Please check your API credentials.');
                } else if (response.status === 403) {
                    throw new Error('Access denied. Please verify your API subscription.');
                } else if (response.status === 429) {
                    throw new Error('Rate limit exceeded. Please try again later.');
                } else {
                    throw new Error(`API request failed with status ${response.status}`);
                }
            }

            return await response.json();
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error.name === 'AbortError') {
                throw new Error('Request timed out. Please check your connection.');
            } else if (error.message.includes('CORS')) {
                throw new Error('CORS error detected. This may be due to browser security restrictions. Try running from a web server or check API configuration.');
            } else if (error.message.includes('Failed to fetch')) {
                throw new Error('Unable to connect to the API. Please check your internet connection and try again.');
            }
            
            throw error;
        }
    }

    parseTrainData(data) {
        if (!data || !data.services || !Array.isArray(data.services)) {
            return [];
        }

        const now = new Date();
        const trains = data.services
            .filter(service => {
                // Filter for upcoming trains only
                const departureTime = this.parseTime(service.locationDetail?.gbttBookedDeparture);
                return departureTime > now;
            })
            .slice(0, this.maxTrains)
            .map(service => this.mapServiceToTrain(service));

        return trains;
    }

    mapServiceToTrain(service) {
        const locationDetail = service.locationDetail || {};
        const scheduledTime = locationDetail.gbttBookedDeparture;
        const realtimeTime = locationDetail.realtimeDeparture;
        
        return {
            id: service.serviceUid || service.runningIdentity || Math.random().toString(36),
            scheduledDeparture: scheduledTime,
            realtimeDeparture: realtimeTime,
            platform: locationDetail.platform || null,
            operator: service.atocName || 'Unknown Operator',
            status: this.determineStatus(scheduledTime, realtimeTime, service.isCancelled),
            isRealtime: locationDetail.realtimeDepartureActual || false
        };
    }

    determineStatus(scheduled, realtime, isCancelled) {
        if (isCancelled) {
            return { type: 'cancelled', text: 'Cancelled' };
        }

        if (!realtime || scheduled === realtime) {
            return { type: 'on-time', text: 'On time' };
        }

        const scheduledMinutes = this.timeToMinutes(scheduled);
        const realtimeMinutes = this.timeToMinutes(realtime);
        const delayMinutes = realtimeMinutes - scheduledMinutes;

        if (delayMinutes <= 2) {
            return { type: 'on-time', text: 'On time' };
        } else {
            return { type: 'delayed', text: `${delayMinutes} min late` };
        }
    }

    displayTrains(trains) {
        this.hideAllStates();
        this.elements.trainsContainer.innerHTML = '';

        trains.forEach(train => {
            const trainCard = this.createTrainCard(train);
            this.elements.trainsContainer.appendChild(trainCard);
        });

        this.startCountdownUpdates();
    }

    createTrainCard(train) {
        const card = document.createElement('div');
        card.className = 'train-card';
        card.innerHTML = `
            <div class="train-card__header">
                <div class="train-time">
                    <span class="train-time__scheduled">${this.formatTime(train.scheduledDeparture)}</span>
                    ${train.realtimeDeparture && train.realtimeDeparture !== train.scheduledDeparture ? 
                        `<span class="train-time__realtime">Expected: ${this.formatTime(train.realtimeDeparture)}</span>` : ''}
                </div>
                <div class="train-countdown">
                    <span>Departing in</span>
                    <span class="countdown-time" data-departure="${train.realtimeDeparture || train.scheduledDeparture}">
                        ${this.getCountdownText(train.realtimeDeparture || train.scheduledDeparture)}
                    </span>
                </div>
            </div>
            <div class="train-card__body">
                <div class="train-info__item">
                    <span class="train-info__label">Platform</span>
                    <span class="train-info__value">
                        ${train.platform ? `<span class="platform-number">${train.platform}</span>` : 'TBC'}
                    </span>
                </div>
                <div class="train-info__item">
                    <span class="train-info__label">Operator</span>
                    <span class="train-info__value">${train.operator}</span>
                </div>
                <div class="train-info__item">
                    <span class="train-info__label">Status</span>
                    <span class="train-info__value">
                        <span class="status-indicator status--${train.status.type}">
                            <span class="status-dot"></span>
                            ${train.status.text}
                        </span>
                    </span>
                </div>
                <div class="train-info__item">
                    <span class="train-info__label">Service</span>
                    <span class="train-info__value">${train.id}</span>
                </div>
            </div>
        `;
        return card;
    }

    startCountdownUpdates() {
        if (this.countdownInterval) {
            clearInterval(this.countdownInterval);
        }

        this.countdownInterval = setInterval(() => {
            const countdownElements = document.querySelectorAll('.countdown-time[data-departure]');
            countdownElements.forEach(element => {
                const departureTime = element.getAttribute('data-departure');
                element.textContent = this.getCountdownText(departureTime);
            });
        }, 1000);
    }

    getCountdownText(timeString) {
        const departureTime = this.parseTime(timeString);
        const now = new Date();
        const diffMs = departureTime - now;

        if (diffMs < 0) {
            return 'Departed';
        }

        const diffMinutes = Math.floor(diffMs / 60000);
        
        if (diffMinutes < 1) {
            return 'Now';
        } else if (diffMinutes === 1) {
            return '1 min';
        } else {
            return `${diffMinutes} mins`;
        }
    }

    parseTime(timeString) {
        if (!timeString || timeString.length !== 4) return new Date();
        
        const hours = parseInt(timeString.substring(0, 2));
        const minutes = parseInt(timeString.substring(2, 4));
        
        const date = new Date();
        date.setHours(hours, minutes, 0, 0);
        
        // If the time is in the past today, assume it's for tomorrow
        if (date < new Date()) {
            date.setDate(date.getDate() + 1);
        }
        
        return date;
    }

    timeToMinutes(timeString) {
        if (!timeString || timeString.length !== 4) return 0;
        const hours = parseInt(timeString.substring(0, 2));
        const minutes = parseInt(timeString.substring(2, 4));
        return hours * 60 + minutes;
    }

    formatTime(timeString) {
        if (!timeString || timeString.length !== 4) return '--:--';
        const hours = timeString.substring(0, 2);
        const minutes = timeString.substring(2, 4);
        return `${hours}:${minutes}`;
    }

    startAutoRefresh() {
        if (this.autoRefreshInterval) {
            clearInterval(this.autoRefreshInterval);
        }

        this.autoRefreshCountdown = 60;
        this.elements.countdown.textContent = this.autoRefreshCountdown;

        this.autoRefreshInterval = setInterval(() => {
            this.autoRefreshCountdown--;
            this.elements.countdown.textContent = this.autoRefreshCountdown;

            if (this.autoRefreshCountdown <= 0) {
                this.loadTrains();
                this.resetAutoRefresh();
            }
        }, 1000);
    }

    resetAutoRefresh() {
        this.autoRefreshCountdown = 60;
        this.elements.countdown.textContent = this.autoRefreshCountdown;
    }

    showLoadingState() {
        this.hideAllStates();
        this.elements.loadingState.classList.remove('hidden');
    }

    showErrorState(message) {
        this.hideAllStates();
        this.elements.errorMessage.textContent = message;
        this.elements.errorState.classList.remove('hidden');
    }

    showNoTrainsState() {
        this.hideAllStates();
        this.elements.noTrainsState.classList.remove('hidden');
    }

    hideAllStates() {
        this.elements.loadingState.classList.add('hidden');
        this.elements.errorState.classList.add('hidden');
        this.elements.noTrainsState.classList.add('hidden');
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TrainDepartureApp();
});